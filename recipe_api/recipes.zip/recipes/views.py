from recipes.filters import RecipeFilter
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets
from .models import Recipe, Ingredient, Step, Review
from .serializers import RecipeSerializer, IngredientSerializer, StepSerializer, ReviewSerializer

class RecipeViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Recipe.objects.all().order_by('-created_at')
    serializer_class = RecipeSerializer

class IngredientViewSet(viewsets.ModelViewSet):
    queryset = Ingredient.objects.all()
    serializer_class = IngredientSerializer

class StepViewSet(viewsets.ModelViewSet):
    queryset = Step.objects.all()
    serializer_class = StepSerializer

class ReviewViewSet(viewsets.ModelViewSet):
    queryset = Review.objects.all()
    serializer_class = ReviewSerializer
