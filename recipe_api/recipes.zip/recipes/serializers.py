from rest_framework import serializers
from .models import Recipe, Ingredient, Step, Review

class IngredientSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ingredient
        fields = ['id', 'name', 'image']

class StepSerializer(serializers.ModelSerializer):
    class Meta:
        model = Step
        fields = ['id', 'order', 'instruction']

class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = ['id', 'name', 'comment', 'rating', 'created_at']
class RecipeSerializer(serializers.ModelSerializer):
    rating = serializers.SerializerMethodField()

    class Meta:
        model = Recipe
        fields = ['id', 'title', 'author', 'time', 'image', 'rating']

    def get_rating(self, obj):
        avg = obj.average_rating()
        return f"{avg:.1f}" if avg is not None else "0.0"
